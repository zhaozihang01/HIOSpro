# HIOS Pro V0.3

可直接部署到 Vercel。

- 真实公开日线行情
- 日K / MA5 / MA25 / MA75 / 成交量
- 支撑位 / 压力位
- HIOS Timing Score
- iPad / iPhone 响应式

数据来自 Yahoo Finance 公开接口，可能延迟或暂时不可用。